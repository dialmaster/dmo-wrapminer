
## Version 1.2.0

**Date of release:** `Sunday 27 February 2022`

**Description:** `Version 1.2.0`

### Included features
1. Added support for SRBMiner

---

## Version 1.1.0

**Date of release:** `Saturday 26 February 2022`

**Description:** `Version 1.1.0`

### Included features
1. Added version check against dmo-monitor.com on startup

---

## Version 1.0.0

**Date of release:** `Saturday 26 February 2022`

**Description:** `Initial Versioned Release`

### Included features
1. Add version string to application
